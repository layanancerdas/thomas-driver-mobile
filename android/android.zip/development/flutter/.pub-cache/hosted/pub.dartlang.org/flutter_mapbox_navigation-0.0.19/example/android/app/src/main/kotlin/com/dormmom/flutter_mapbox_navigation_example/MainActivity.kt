package com.dormmom.flutter_mapbox_navigation_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
    
}
