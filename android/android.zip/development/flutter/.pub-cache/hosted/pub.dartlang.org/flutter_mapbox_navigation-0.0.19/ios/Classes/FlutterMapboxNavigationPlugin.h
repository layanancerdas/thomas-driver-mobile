#import <Flutter/Flutter.h>

@interface FlutterMapboxNavigationPlugin : NSObject<FlutterPlugin>
@end
