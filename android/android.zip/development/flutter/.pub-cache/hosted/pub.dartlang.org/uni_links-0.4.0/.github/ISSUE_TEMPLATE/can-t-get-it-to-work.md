---
name: Can't get it to work
about: You've got an issue, using the package

---

I'm using [https scheme, custom scheme, https and custom schemes] and am testing
on my [iPhone6, Google Pixel, iOS Simulator, Android Emulator],
which is running [iOS8.1, Android 8: Oreo].

...add any other context about the problem here.

e.g. I call '...' method and... nothing happens!!!
