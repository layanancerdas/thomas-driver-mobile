#import <Flutter/Flutter.h>

@interface GeolocatorPlugin : NSObject<FlutterPlugin>
@end
